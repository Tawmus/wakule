function extFunc() {
       document.getElementById("extFuncPar").innerHTML = "Paragraph changed.";
} 
